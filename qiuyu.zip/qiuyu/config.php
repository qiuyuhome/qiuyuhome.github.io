<?php
/**
 * Created by PhpStorm.
 * User: qiuyu
 * Date: 2017/3/22
 * Time: 下午6:29
 */

return (
    array(
        /**
         * author: qiuyu
         * date: 2017-03-29
         * 爬虫控制参数
         */
        'host'=>'http://localhost:4444/wd/hub',     // selenium服务器地址    http://localhost:4444/wd/hub
        'url'=>'https://www.amazon.com/gp/goldbox', // 主页地址, 需要爬取的deals主页.
        'browser'=>'phantomjs',                     // 浏览器驱动名称  phantomjs, chrome
        // 浏览器 User-Agent.
        'useragent'=>array(
            'mac_chrome'=>'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36',
            'mac_safari'=>'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_3) AppleWebKit/602.4.8 (KHTML, like Gecko) Version/10.0.3 Safari/602.4.8',
            'mac_firefox'=>'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:52.0) Gecko/20100101 Firefox/52.0',
            'win_chrome'=>'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.98 Safari/537.36',
            'win_firefox'=>'',
        ),
        'requestTimeout'=>100000,                   // 请求selenium服务器的时间, 单位毫秒   30000
        'waitSeconds'=>1,                           // 网页等待元素出现的事件. 单位, 秒.
        'connectionTimeout'=>2000,                  // 连接selenium服务器超时时间, 单位毫秒. 5000
        'implicitlyWait'=>1,                        // 查找元素的超时时间, 搜索元素不存在时等待的时间, 单位秒.
        'blank'=>true,                              // 是否新窗口打开页面, true, false
        'debug'=>true,

        /**
         * 主页点击商品, 判断是列表页还是详情页的规则.
         *
         * author: qiuyu
         * date: 2017-03-29
         */
        'listRules'=> array(
            array(
                'html_flag'=>'<div id="search-results" class="a-section" role="contentinfo">',
                // 'cssSelector'=>'#search-results a[title]:not([title="Image View"]',
                'cssSelector'=>'#search-results li > div > div:nth-child(3) > div:nth-child(1) > a',
            ),
            array(
                'html_flag'=>'<div id="resultsCol" class="">',
                'cssSelector'=>'#resultsCol a[title]:not([title="Image View"])',
            ),
        ),

        /**
         * 判断是否是列表页的规则, 根据URL判断.
         *
         * author: qiuyu
         * date: 2017-04-01
         */
         'isListPage'=>array(
            // ok
            array(
                'desc'=>'',
                'demo'=>'https://www.amazon.com/s/browse/ref=gbps_img_s-3_596a_c475a82a?ie=UTF8&node=12412654011&smid=ATVPDKIKX0DER&pf_rd_p=af76a610-c28c-4f12-9308-ccc69eba596a&pf_rd_s=slot-3&pf_rd_t=701&pf_rd_i=gb_main&pf_rd_m=ATVPDKIKX0DER&pf_rd_r=MKP4Z9PFZSFGYSE9702A',
                'url'=>'https://www.amazon.com/s/browse/',
                'cssSelector'=>'#search-results li a[title]',
            ),

            // ok
            array(
                'desc'=>'',
                'demo'=>'https://www.amazon.com/b/ref=gbps_img_s-3_596a_879d9b02?node=16512495011&smid=ATVPDKIKX0DER&pf_rd_p=af76a610-c28c-4f12-9308-ccc69eba596a&pf_rd_s=slot-3&pf_rd_t=701&pf_rd_i=gb_main&pf_rd_m=ATVPDKIKX0DER&pf_rd_r=MKP4Z9PFZSFGYSE9702A',
                'url'=>'https://www.amazon.com/b/',
                'cssSelector'=>'#search-results li a[title]',
            ),

            array(
                'desc'=>'waterfall',
                'demo'=>'https://www.amazon.com/dlp/0484eceb/ref=gbps_img_s-3_596a_0484eceb?smid=ATVPDKIKX0DER&pf_rd_p=af76a610-c28c-4f12-9308-ccc69eba596a&pf_rd_s=slot-3&pf_rd_t=701&pf_rd_i=gb_main&pf_rd_m=ATVPDKIKX0DER&pf_rd_r=MKP4Z9PFZSFGYSE9702A',
                'url'=>'https://www.amazon.com/dlp/',
                'cssSelector'=>'.acs-wtfl-grid > div:nth-child(1) > div:nth-child(1) > div.acs-wtfl-card-details > div:nth-child(1) > a:nth-child(1)',
            ),

            // ok
            array(
                'desc'=>'',
                'demo'=>'https://www.amazon.com/s/ref=gbps_img_s-3_596a_b8049902?fst=as%3Aoff&rh=n%3A7141123011%2Cn%3A9479199011%2Cp_89%3AAmazonBasics%2Cp_28%3AAmazonBasics+Packing+Cubes%2Cp_6%3AATVPDKIKX0DER%2Cp_8%3A2661605011&bbn=9479199011&ie=UTF8&qid=1490131979&rnid=2661603011&lo=fashion-luggage&ajr=2&smid=ATVPDKIKX0DER&pf_rd_p=af76a610-c28c-4f12-9308-ccc69eba596a&pf_rd_s=slot-3&pf_rd_t=701&pf_rd_i=gb_main&pf_rd_m=ATVPDKIKX0DER&pf_rd_r=MKP4Z9PFZSFGYSE9702A',
                'url'=>'https://www.amazon.com/s/',
                'cssSelector'=>'#resultsCol a[title]:not([title="Image View"])',
            ),

            // ok
            array(
                'desc'=>'dvd',
                'demo'=>'https://www.amazon.com/movies-tv-dvd-bluray/b/ref=gbps_img_s-3_596a_cbecaff1?ie=UTF8&node=15497965011&smid=ATVPDKIKX0DER&pf_rd_p=af76a610-c28c-4f12-9308-ccc69eba596a&pf_rd_s=slot-3&pf_rd_t=701&pf_rd_i=gb_main&pf_rd_m=ATVPDKIKX0DER&pf_rd_r=MKP4Z9PFZSFGYSE9702A',
                'url'=>'https://www.amazon.com/movies-tv-dvd-bluray/b/',
                'cssSelector'=>'#search-results ul > li > div > div > div > div.a-fixed-left-grid-col.a-col-left > div > div > a',
            ),
         ),

        /**
         * 详细页需要点击元素的匹配规则, 下表越小优先级越高, 目前最多支持匹配到2个规则. 下表是4的, 是下拉列表. 所以是个数组.
         *
         * author: qiuyu
         * date: 2017-03-29
         */
        'detailRules'=>array(
            1=>'#variation_style_name li',
            2=>'#variation_size_name li',
            3=>'#shelfSwatchSection-size_name div[id^="size_name_"]',
            4=>array(
                "#native_dropdown_selected_size_name",
                '#native_dropdown_selected_size_name option[id^="native_size_name_"]'
            ),
            5=>'#variation_edition li[id^="edition_"]',
            6=>'#buyboxPrices_feature_div div[id^=mocaBuyBoxQtyOpt_]',
            100=>'#variation_color_name li:not(.swatchUnavailable)',
            101=>"#shelfSwatchSection-color_name div[id^='color_name']",
        ),

        /**
         * 首页下一页规则
         */
        'homeNextPage'=>'#FilterItemView_page_pagination .a-declarative > div:nth-child(1) li:last-child',
    )
);