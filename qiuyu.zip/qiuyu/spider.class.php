<?php
/**
 * spider for amazon
 *
 * User: qiuyu, chenyu, minsongtao
 * Date: 2017/3/24
 */
namespace Facebook\WebDriver;

use Facebook\WebDriver\Remote\DesiredCapabilities;
use Facebook\WebDriver\Remote\RemoteWebDriver;

require_once('vendor/autoload.php');

class spider
{
    // browser driver
    private $driver;

    // search html element time, ms
    private $findElementTime;

    // debug switch
    public $debug = false;

    // list page handle
    private $listHandle;

    // home page handle
    private $homeHandle;

    // detail page handle
    private $detailHandle;

    // list page rules
    private $listRules;

    // css selector
    private $cssSelector;

    private $_config;

    private $capabilities;

    private $time;

    // 当前主页中的第几个商品
    private $homeNum;

    // 当前列表页中的第几个商品
    private $listNum;

    // 当前详细页中的第几个商品
    private $detailNum;

    // 主页的总页数
    private $homePageCount;

    // 列表页的总页数
    private $listPageCount;

    // 当前是主页中的第几页
    private $homePageNum;

    // 当前是列表页中的第几页
    private $listPageNum;

    // 列表页中每页的商品数量
    private $listPerNum;

    // 当前主页中有多少个商品
    private $homeGoodsCount;

    // 当前列表页中有多少个商品
    private $listGoodsCount;

    // 详细页有几种可点击元素
    private $elementsNum;

    // 详细页第一种元素的个数
    private $oneElementCount;

    // 详细页第二种元素的个数
    private $twoElementCount;

    // 详细页第一种元素中第几个
    private $oneClickNum;

    // 详细页第二种元素中第几个
    private $twoClickNum;

    public function position()
    {
        $msg = "\n\n当前位置:\n";
        if ($this->homePageCount && $this->homePageNum) {
            $msg .= " HOME --> 共 $this->homePageCount 页, 每页 $this->homeGoodsCount 个 --> 第 $this->homeNum 个商品 \n";
        }

        if ($this->listPerNum) {
            $msg .= " LIST --> 共 $this->listPageCount 页, $this->listGoodsCount 个商品, 每页 $this->listPerNum 个";
        }

        if ($this->listNum) {
            $msg .= " --> 第 $this->listNum 个商品 \n";
        }

        if ($this->oneElementCount) {
            $msg .= " DETAIL --> 共 $this->elementsNum 种元素, 第一种 $this->oneElementCount 个 ";
        }

        if ($this->twoElementCount) {
            $msg .= ", 第二种 $this->twoElementCount 个";
        }

        if ($this->oneClickNum) {
            $msg .= " , 当前点击: 第一种 -> ".$this->oneClickNum;
        }

        if ($this->twoClickNum) {
            $msg .= " ,  第二种 -> ".$this->twoClickNum;
        }
        $msg .= "\n";
        $this->debug($msg);
    }

    /**
     * spider begin
     *
     * author: qiuyu
     * date: 2017-03-29
     * @param: array $_config
     */
    public function begin($_config)
    {
        $this->time = microtime(TRUE);
        $this->debug("\n\n\n************开始************");
        if (empty($_config)) {
            die('config is empty, should be a array');
        }
        $this->_config = $_config;

        if (!isset($this->_config['listRules']) || empty($this->_config['listRules'])) {
            $this->debug('配置文件不能为空');die;
        }

        $this->listRules = $_config['listRules'];

        $this->capabilities = DesiredCapabilities::phantomjs();
        // $this->capabilities->setCapability("phantomjs.page.settings.userAgent", $this->_config['useragent']['mac_chrome']);
        $this->driver = RemoteWebDriver::create(
            $this->_config['host'],
            $this->capabilities,
            $this->_config['connectionTimeout'],
            $this->_config['requestTimeout']
        );
        $window = new WebDriverDimension(1200, 1000);
        $this->driver->manage()->window()->setSize($window);
        // $this->driver->manage()->window()->maximize();
        // $this->driver->manage()->deleteAllCookies();
        $this->driver->manage()->timeouts()->implicitlyWait($this->_config['implicitlyWait']);

        /*↓↓↓↓↓↓↓↓↓↓↓ qiuyu test begin ↓↓↓↓↓↓↓↓↓↓↓*/

        /**
         * 列表页规则测试
         */
        // $this->driver->get("https://www.amazon.com/s/ref=gbps_img_s-3_596a_eca96818?node=16351920011&field-enc-merchantbin=ATVPDKIKX0DER&lo=none&smid=ATVPDKIKX0DER&pf_rd_p=af76a610-c28c-4f12-9308-ccc69eba596a&pf_rd_s=slot-3&pf_rd_t=701&pf_rd_i=gb_main&pf_rd_m=ATVPDKIKX0DER&pf_rd_r=XJNEQF7TAFHGJ948XEPC");
        //
        // $listPageRule = $this->isListPageWithUrl();
        //
        // if (!$listPageRule) {
        //     $this->detailPageAction();
        //     $this->driver->switchTo()->window($this->homeHandle);
        // } else {
        //     do {
        //         $this->listPageAction($listPageRule);
        //         $loop = $this->isExistNextPageNew();
        //     } while ($loop);
        //     $this->listNum = 0;
        //     $this->listPageCount = 0;
        //     $this->listPerNum = 0;
        //     $this->listGoodsCount = 0;
        //     $this->debug("关闭列表页");
        //     $this->driver->close();
        //     $this->driver->switchTo()->window($this->homeHandle);
        // }
        // $this->switchToEndWindow();
        // die;


        /**
         * 详细页规则测试
         */
        // $this->driver->get("https://www.amazon.com/Hoover-BH50010-Cordless-Vacuum-Cleaner/dp/B001PB8EJ2/ref=gbps_img_s-3_bb19_fd6c8656?smid=ATVPDKIKX0DER&pf_rd_p=41fd713f-6bfe-4299-a021-d2b94872bb19&pf_rd_s=slot-3&pf_rd_t=701&pf_rd_i=gb_main&pf_rd_m=ATVPDKIKX0DER&pf_rd_r=084EP7GHDPE0154X7S2D&th=1");
        // $this->detailPageAction();
        // die;


        /*↑↑↑↑↑↑↑↑↑↑↑ qiuyu test over  ↑↑↑↑↑↑↑↑↑↑↑*/

        $this->debug('打开网页');
        $this->driver->get($this->_config['url']);

        $this->homePageActionNew();
    }

    /**
     * open new tab
     *
     * author: qiuyu
     * date: 2017-03-30
     */
    public function openNewTab()
    {
        $this->debug('使用js打开新标签');
        $js = 'window.open("", "_blank");';
        $this->driver->executeScript($js);
    }

    /**
     * deals home page action
     *
     * author: qiuyu
     * date: 2017-03-29
     */
    public function homePageActionNew()
    {
        // scroll down
        $this->debug('滑动滚动条');
        $js = "window.scrollBy(0,100000000);";
        $this->driver->executeScript($js);

        $this->openPageType('_blank');

        $element = $this->driver->findElement(WebDriverBy::cssSelector("#FilterItemView_page_pagination ul.a-pagination>li:nth-child(6)"));
        $this->homePageCount = $element->getText();

        $element = $this->driver->findElement(WebDriverBy::cssSelector("#FilterItemView_page_pagination ul.a-pagination>li.a-selected>a"));
        $this->homePageNum = $element->getText();

        // 获取首页的窗口句柄
        $homeHandle = $this->driver->getWindowHandles();
        $this->homeHandle = $homeHandle[0];

        $elements = $this->driver->findElements(WebDriverBy::cssSelector("#widgetContent div[id^='100_dealView_'] a#dealImage"));

        foreach ($elements as $v) {
            $this->homeGoodsCount += 1;
        }

        $this->debug('遍历主页');

        do {
            for ($i = 0; $i < $this->homeGoodsCount; $i++) {
                $this->homeNum += 1;
                $id = "100_dealView_" . $i;
                $js = 'document.getElementById("' . $id . '").querySelector("a").setAttribute("target","_blank");';
                $js .= 'document.getElementById("' . $id . '").querySelector("a").click();';
                $this->driver->executeScript($js);
                $this->switchToEndWindow();
                $this->position();
                $listPageRule = $this->isListPageWithUrl();

                if (!$listPageRule) {
                    $this->detailPageAction();
                    $this->driver->switchTo()->window($this->homeHandle);
                } else {
                    do {
                        $this->listPageAction($listPageRule);
                        $loop = $this->isExistNextPageNew();
                    } while ($loop);
                    $this->listNum = 0;
                    $this->listPageCount = 0;
                    $this->listPerNum = 0;
                    $this->listGoodsCount = 0;
                    $this->debug("关闭列表页");
                    $this->driver->close();
                    $this->driver->switchTo()->window($this->homeHandle);
                }
                $this->switchToEndWindow();
                $this->rand_sleep(0.1, 2);
            }

            try {
                // $element = $this->driver->findElement(WebDriverBy::cssSelector($this->_config['homeNextPage']));
                // $element->click();
                $this->driver->findElement(WebDriverBy::partialLinkText('Next'))->click();
                $homeLoop = true;
            } catch (\Exception $e) {
                $this->debug('首页, 没有找到首页的下一页, 结束');
                die;
            }
        } while ($homeLoop);
    }

    /**
     * deals home page action
     *
     * author: qiuyu
     * date: 2017-03-29
     */
    public function homePageAction()
    {
        // scroll down
        $this->debug('滑动滚动条');
        $js = "window.scrollBy(0,100000000);";
        $this->driver->executeScript($js);

        $this->debug('遍历主页');
        $this->openPageType('_blank');

        $this->driver->wait($this->_config['waitSeconds'])->until(
            WebDriverExpectedCondition::visibilityOfElementLocated(
                WebDriverBy::cssSelector("#FilterItemView_page_pagination li.a-selected")
            )
        );

        $element = $this->driver->findElement(WebDriverBy::cssSelector("#FilterItemView_page_pagination ul.a-pagination>li:nth-child(6)"));
        $this->homePageCount = $element->getText();

        $element = $this->driver->findElement(WebDriverBy::cssSelector("#FilterItemView_page_pagination ul.a-pagination>li.a-selected>a"));
        $this->homePageNum = $element->getText();

        // 获取首页的窗口句柄
        $homeHandle = $this->driver->getWindowHandles();
        $this->homeHandle = $homeHandle[0];

        $elements = $this->driver->findElements(WebDriverBy::cssSelector("#widgetContent div[id^='100_dealView_'] a#dealImage"));

        $urls = array();
        foreach ($elements as $v) {
            $url = $v->getAttribute('href');
            if ($url) {
                $urls[] = $url;
                $this->homeGoodsCount += 1;
            }
        }

        // 遍历打开商品的链接.
        foreach ($urls as $key => $url) {
            $this->openNewTab();
            $this->switchToEndWindow();
            $this->driver->get($url);
            $this->homeNum += 1;

            $this->position();

            if (!$this->isListPage()) {
                $this->debug("不是列表页");
                $this->detailPageAction();
                $this->debug("切换为主页的窗口句柄");
                $this->driver->switchTo()->window($this->homeHandle);
            } else {
                $this->debug("是列表页");
                $this->debug("遍历列表页开始");

                // do {
                //     // $loop = $this->isExistNextPage();
                //     // $this->listPageAction();
                //     // if ($loop) {
                //     //     $this->driver->get($loop);
                //     // }
                //     $this->listPageAction();
                //     $loop = $this->isExistNextPageNew();
                // } while ($loop);
                $this->listNum = 0;
                $this->listPageCount = 0;
                $this->listPerNum = 0;
                $this->listGoodsCount = 0;
                $this->debug("关闭列表页");
                $this->driver->close();
                $this->debug("切换为主页的窗口句柄");
                $this->driver->switchTo()->window($this->homeHandle);
            }
            $this->switchToEndWindow();
            $usec = rand(1000000,3000000);
            $this->debug('延时'.$usec.'微妙');
            usleep($usec);
        }
    }

    /**
     * list page action
     *
     * author: qiuyu
     * date: 2017-03-29
     */
    public function listPageAction($cssSelector)
    {
        $this->openPageType('_blank');

        $listHandle = $this->driver->getWindowHandles();
        $listKey = count($listHandle) - 1;
        $this->listHandle = $listHandle[$listKey];
        $elements = $this->driver->findElements(WebDriverBy::cssSelector($cssSelector));

        if (empty($elements)) {
            $this->debug('列表页根据规则获取元素失败');
            die;
        }

        try {
            $result = $this->driver->findElement(WebDriverBy::cssSelector('h2#s-result-count'))->getText();
            $result = trim(strstr($result, 'results for', true));
            if (strpos($result, ' of ')) {
                $arr = explode('of', $result);
                $tmparr = explode('-', $arr[0]);
                $this->listGoodsCount = $arr[1];
                $this->listPerNum = trim($tmparr[1]) - trim($tmparr[0]) + 1;
                $this->listPageCount = ceil($this->listGoodsCount / $this->listPerNum);
                $this->position();
            }
        } catch (\exception $e) {
            $this->debug('记录商品数量信息失败');
        }

        $this->debug("开始遍历列表页中的商品");
        foreach ($elements as $v) {
            $this->driver->switchTo()->window($this->listHandle);
            $this->listNum += 1;
            $this->position();
            try {
                $v->click();
                $this->rand_sleep(0.1, 1);
                $this->switchToEndWindow();
                $this->detailPageAction();
            } catch (\Exception $e) {
                $this->debug('元素不可以点击');
            }
        }

        // 切换为列表句柄
        $this->driver->switchTo()->window($this->listHandle);
    }

    /**
     * is exist next page
     *
     * author: qiuyu
     * date: 2017-03-29
     * @return bool
     */
    public function isExistNextPage()
    {
        $this->debug("判断是否存在下一页");
        $loop = false;

        $isExistNextPage = $this->isElementsExsit('#pagnNextLink', true);
        if ($isExistNextPage) {
            $loop = true;
            $nextPage = $this->driver->findElement(WebDriverBy::cssSelector('#pagnNextLink'));
            $url = $nextPage->getAttribute('href');
            return $url;
        }
        return $loop;
    }

    /**
     * is exist next page
     *
     * author: qiuyu
     * date: 2017-03-29
     * @return bool
     */
    public function isExistNextPageNew()
    {
        $this->debug("判断是否存在下一页");
        $loop = false;

        $isExistNextPage = $this->isElementsExsit('a#pagnNextLink', true);
        if ($isExistNextPage) {
            $this->debug("-->yes");
            $this->debug("点击下一页");
            try {
                $loop = true;
                $this->openPageType('_self');
                $nextPage = $this->driver->findElement(WebDriverBy::cssSelector('a#pagnNextLink'));
                $nextPage->sendKeys('xxx')->click();
                usleep($ussec);
                $this->switchToEndWindow();
            } catch (\Exception $e) {
                $js = 'document.getElementById("pagnNextLink").click()';
                $this->driver->executeScript($js);
                $this->switchToEndWindow();
            }
        } else {
            $this->debug("-->no");
        }
        return $loop;
    }

    /**
     * is list page
     *
     * author: qiuyu
     * date: 2017-03-29
     * @return bool
     */
    public function isListPageWithUrl()
    {
        $this->debug('判断是否是列表页');

        try {
            $url = $this->driver->getCurrentUrl();
            foreach ($this->_config['isListPage'] as $key=>$val) {
                if (strpos($url, $val['url']) !== false) {
                    $this->debug('-->yes');
                    return $val['cssSelector'];
                }
            }
        } catch (\Exception $e) {
            $this->debug('-->no');
            return false;
        }

    }

    /**
     * is list page
     *
     * author: qiuyu
     * date: 2017-03-29
     * @return bool
     */
    public function isListPage()
    {
        $this->debug('判断是否是列表页');

        try {
            $element = $this->driver->findElement(WebDriverBy::cssSelector('#sx-hms-heading>h4'));
            $text = $element->getText();
            if ($text == 'Search Feedback') {
                return true;
            } else {
                return false;
            }
        } catch (\Exception $e) {
            return false;
        }

    }

    /**
     * open new page type
     *
     * author: qiuyu
     * date: 2017-03-29
     * @param string $type, _self , _blank, default: _self
     * @return bool
     */
    public function openPageType($type)
    {
        if ($type == "_blank") {
            $js = <<<js
            var tag_a = document.getElementsByTagName("a");
            for (var i = tag_a.length - 1; i >= 0; i--) {
                tag_a[i].setAttribute("target", "_blank");
            };
js;
        } elseif($type == "_self") {
            $js = <<<js
            var tag_a = document.getElementsByTagName("a");
            for (var i = tag_a.length - 1; i >= 0; i--) {
                tag_a[i].setAttribute("target", "_self");
            };
js;
        }else{
            log::error("openPageType param is error");
            die;
        }

        $this->driver->executeScript($js);
        return array('errNo'=>0, 'result'=>true);
    }

    /**
     * switch last one window
     *
     * author: qiuyu
     * date: 2017-03-29
     */
    public function switchToEndWindow()
    {
        $this->debug("切换为最后一个窗口句柄");
        $arr = $this->driver->getWindowHandles();
        foreach ($arr as $k=>$v){
            if($k == (count($arr)-1)){
                $this->driver->switchTo()->window($v);
            }
        }
    }

    /**
     * is exist elements
     *
     * author: qiuyu
     * date: 2017-03-29
     * @param WebDriverBy $locator
     * @param bool  $onlyOne
     * @return $elements or false
     */
    function isElementsExsit($locator, $onlyOne = false)
    {
        try {
            if ($onlyOne) {
                $elements = $this->driver->findElement(WebDriverBy::cssSelector($locator));
            } else {
                if (is_array($locator) && count($locator) == 2) {
                    $elements = $this->driver->findElement(WebDriverBy::cssSelector($locator[0]))
                        ->findElements(WebDriverBy::cssSelector($locator[1]));
                } else {
                    $elements = $this->driver->findElements(WebDriverBy::cssSelector($locator));
                }
            }
            return $elements;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * delay
     *
     * author: qiuyu
     * date: 2017-04-01
     * @param $start
     * @param $end
     * @param bool $usleep
     */
    public function rand_sleep($start, $end, $usleep = true)
    {
        if ($usleep) {
            $start *= 1000000;
            $end *= 1000000;
            $usec = rand($start, $end);
            $sec = sprintf("%.3f", ($usec / 1000000));
            $this->debug('延时: '.$sec.' 秒');
            usleep($usec);
        } else {
            $sec = rand($start, $end);
            $this->debug('延时: '.$sec.' 秒');
            sleep($sec);
        }
    }

    /**
     * detail page action
     *
     * author: qiuyu
     * date: 2017-03-29
     */
    public function detailPageAction()
    {
        $this->debug("进入详细页, 判断是否有需要点击的元素");
        $flag = false;

        $goodsStyleArray = array();
        foreach ($this->_config['detailRules'] as $key=>$rule) {
            $elements = $this->isElementsExsit($rule);

            if ($elements) {
                $flag = true;
                $goodsStyleArray[] = $elements;
            }
        }

        ksort($goodsStyleArray);
        $goodsStyleArray = array_values($goodsStyleArray);


        // whether there is a need to click on the element
        if ($flag) {
            // init
            $this->elementsNum = 0;
            $this->oneElementCount = 0;
            $this->twoElementCount = 0;
            $this->oneClickNum = 0;
            $this->twoClickNum = 0;

            $this->elementsNum = count($goodsStyleArray);
            $this->oneElementCount = count($goodsStyleArray[0]);
            if ($this->elementsNum > 1) {
                $this->twoElementCount = count($goodsStyleArray[1]);
            }

            foreach ($goodsStyleArray[0] as $v) {
                $this->oneClickNum += 1;
                $this->position();
                try {
                    $v->click();
                } catch (\Exception $e) {
                    $this->debug('****点击第 1 种元素失败.****');
                    continue;
                }

                $this->rand_sleep(0.1, 1);

                if (count($goodsStyleArray) > 1) {
                    foreach ($goodsStyleArray[1] as $color) {
                        $this->debug("点击第 2 种元素");
                        $this->twoClickNum += 1;
                        $this->position();
                        try {
                            $color->click();
                        } catch (\Exception $e) {
                            $this->debug('****点击第 2 种元素失败.****');
                            continue;
                        }
                        $this->switchToEndWindow();
                        $html = $this->driver->getPageSource();
                        // TODO ChenYu
                        // $this->Detail();
                        $this->debug("标题: ".$this->driver->getTitle());
                        $this->debug("URL: ".$this->driver->getCurrentUrl());

                    }
                } else {
                    $this->switchToEndWindow();
                    $html = $this->driver->getPageSource();
                    // TODO ChenYu
                    // $this->Detail();
                    $this->debug("标题: ".$this->driver->getTitle());
                    $this->debug("URL: ".$this->driver->getCurrentUrl());
                }
            }
        // no exist click element
        } else {
            $this->debug("无可点击元素");
            $this->switchToEndWindow();
            $html = $this->driver->getPageSource();
            // TODO ChenYu
            // $this->Detail();
            $this->debug("标题: ".$this->driver->getTitle());
            $this->debug("URL: ".$this->driver->getCurrentUrl());

        }

        // close detail page window, and switch window handle
        $this->debug("关闭详情页窗口");
        $this->driver->close();
        // $this->switchToEndWindow();
    }

    /**
     * Details record
     *
     * author:chenyu
     * date:2017-3-29
     * Detial start
     */
    public function Detail(){
        $this->debug("开始记录");
        $this->writes("<<<<<<<<START################\r\n");

        // 记录URL
        $currnetUrl = $this->driver->getCurrentUrl();
        $this->writes("<<<URL:\r\n".$currnetUrl);
        $this->writes("\r\n__________________________________\r\n");

        //得到标题
        $title = $this->driver->getTitle();
        //$driver->quit();
        //die;
        $this->writes("<<<标题::\r\n".$title);
        $this->writes("\r\n__________________________________\r\n");
        //分类
        if($this->isElementsExsit('#wayfinding-breadcrumbs_feature_div')) {
            $select = $this->driver->findElement(WebDriverBy::id('wayfinding-breadcrumbs_feature_div'));
            $seletcts = $select->getText();
            $this->writes("<<<分类::\r\n" . $seletcts);
            $this->writes("\r\n__________________________________\r\n");
        }
        //商品
        if($this->isElementsExsit('#aiv-main-content')){//判断是否电影系列
            $this->each('#aiv-main-content','<<<电影::');
            $this->each('#dv-center-features','<<<Product details::');
        }elseif($this->isElementsExsit('#swaReminderHeader_feature_div')){
            $this->each('#swaDetailPage','<<<food::');
            $this->each('#swaProductDetail','<<<Product Details::');
            $this->each('#swaComparePlans','<<<COMPARE PLANS::');
            $this->each('#swaHowItWorks','<<<How it Works::');
            $this->each('#swaFinePrint','<<<THE FINE PRINT::');
        }else{//商品系列
            $bool = $this->isElementsExsit('#centerCol #title');
            if($bool){
                $this->each('#centerCol','<<<商品详情::');
            }elseif($this->isElementsExsit('#leftCol #title')){
                $this->each('#leftCol','<<<商品详情::');
            }
            if($this->isElementsExsit('#rightCol #centerCol')){
                $this->each('#rightCol','<<<商品价格属性::');
            }
            //个别价格标签
            $this->ifsh('#price','<<<价格::');
            //From the Manufacturer
            $this->ifsh('#aplus_feature_div','<<<FROM_THE_MANUFACTURER::');
            //product description
            $this->ifsh('#descriptionAndDetails','<<<PRODUCT_DESCRIPTION::');

            //product information
            $this->ifsh('#prodDetails','<<PRODUCT_INFORMATION::');

            //section
            $this->ifsh('.kmd-section-text-body',"SECTION");

            //TECHNICAL-DETAILS
            $this->ifsh('#technical-details-table','<<<TECHNICAL-DETAILS::');

            //COMPARE
            $this->ifsh('#ce-comp-lt-table','<<<COMPARE::');

            //PRODUCT_DETAILS
            $this->ifsh('#detail-bullets','<<<PRODUCT_DETAILS::');
            //IMPORTANT_INFORMATION
            $this->ifsh('#importantInformation','<<<IMPORTANT_INFORMATION::');
        }


        $this->writes("END>>>>>>>>>>>>>>>>>>>>>>>>>>\r\n");
        $this->debug('记录结束');
    }

    /**
     * debug, write log, print msg
     *
     * author: qiuyu
     * date: 2017-03-29
     * @param $msg
     * @param bool $show
     * @param $logPath
     */
    public function debug($msg, $show = true, $logPath = "./spider.log")
    {
        $time = microtime(TRUE);
        $useTime = $time - $this->time;
        $this->time = $time;
        $msg = date("Y-m-d H:i:s")." useTime: ".sprintf("%.3f", $useTime)."  ".$msg. "\n";
        if ($show) {
            echo $msg;
        }
        file_put_contents($logPath, $msg, FILE_APPEND | LOCK_EX);
    }

    /**
     * The judgment element is present and output
     *
     * @param $type
     * @param  $Attributes
     * author:chenyu
     * date:2017-3-29
     */
    public function ifsh($type,$Attributes){
        if($this->isElementsExsit($type)){
            $this->each($type,$Attributes);
        }
    }

    /**
     * Loop the tag element
     *
     * @param WebDriver $driver
     * @param  $name
     * @param  $Attributes
     * author:chenyu
     * date:2017-3-29
     */
    public function each($name,$Attributes){
        $this->writes($Attributes."\r\n");
        $data = $this->driver->findElements(WebDriverBy::cssSelector($name));
        foreach($data as $v) {
            $word = $v->getText();
            $this->writes($word);
        }
        $this->writes("\r\n__________________________________\r\n");

    }

    /**
     *Write the file
     *
     * @param $word
     * author:chenyu
     * date:2017-3-29
     */

    public function writes($word){
        $filename = 'Detail_log_new_5.txt';
        $fh = fopen($filename, "a");
        fwrite($fh, $word);
        fclose($fh);
    }
}